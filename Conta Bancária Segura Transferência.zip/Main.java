import java.util.Scanner;
public class Main {
		
	public static void main (String[] args) {
		Scanner in = new Scanner(System.in);
		SafeBankAccount accountOrigin = createAccount(in, "origem");
		SafeBankAccount accountDestiny = createAccount(in, "destino");
		int amount = getIntValue(in,"Valor a transferir em centimos:");
		transferMoney(accountOrigin, accountDestiny, amount); //Porqu� amount e n�o value?
		printAccount(accountOrigin, "origem");
		printAccount(accountDestiny, "destino");
		in.close();
	}
		private static SafeBankAccount createAccount(Scanner in,String name){
			SafeBankAccount account = new SafeBankAccount();
			System.out.println("Conta " + name);
			int initial = getIntValue(in,"Saldo inicial em centimos:");
			if (initial > 0)
				account.deposit(initial);
			return account;

	}	
		private static int getIntValue(Scanner in, String msg){
			System.out.println(msg);
			int value = in.nextInt();
			in.nextLine();
			return value;
	}
		private static void transferMoney(SafeBankAccount accountOrigin, SafeBankAccount accountDestiny, int value) {
			if(accountOrigin.getBalance()>=value && value>=0) {
				accountOrigin.withdraw(value);
				accountDestiny.deposit(value);
				System.out.println("Transfer�ncia efetuada com sucesso.");
			}
			else
				System.out.println("Transfer�ncia n�o efetuada.");
		}
		private static void printAccount(SafeBankAccount account, String name) {
			System.out.print("Saldo conta " + name + ": ");
			System.out.println(account.getBalance()+ " centimos");
		}
}