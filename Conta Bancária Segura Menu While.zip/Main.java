import java.util.Scanner;
public class Main {
	
	public static void main (String[] args) {
	Scanner input = new Scanner(System.in);
	//Criar conta
	SafeBankAccount account = createAccount(input, "cliente");
	
	String comando = "";
	while(!comando.contentEquals("S")) {
		//apresentar o menu
		printMenu();
		comando = readOption(input);
		//executar a operacao escolhida
		executeOption(input, account, comando);
	}
	input.close();
	}
	private static SafeBankAccount createAccount(Scanner in, String msg) {
		SafeBankAccount acc;
		//Pedir saldo inicial
		System.out.print("Saldo inicial da conta " + msg +": ");
		//Ler valor do utilizador
		int balance = getIntValue(in);
		//Validar valor do utilizador: Se for positivo criar a conta com o saldo indicado, se n�o criar a conta com saldo zero 
		if(balance>0)
			acc = new SafeBankAccount(balance);
		else
			acc = new SafeBankAccount();
		return acc;
		
	}
	private static String readOption(Scanner in) {
		return in.next().toUpperCase();
	}
	private static int getIntValue(Scanner input) {
		int val = input.nextInt(); input.nextLine();
		return val;
	}
	//Definir constantes para cada acao
	private static final String DEPOSIT = "D";
	private static final String WITHDRAW = "L";
	private static final String GETBALANCE = "CS";
	private static final String COMPUTE_INTEREST = "CJA";
	private static final String APPLY_INTEREST = "AJA";
	private static final String SAVING_YEARS = "SY";
	private static final String EXIT = "S";
	
	private static void printMenu() {
		//Escrever o menu
		System.out.println(DEPOSIT + " <valor a depositar> - Depositar");
		System.out.println(WITHDRAW + " <valor a levantar> - Levantar");
		System.out.println(GETBALANCE + " - Consultar saldo");
		System.out.println(COMPUTE_INTEREST + " - Consultar juro anual");
		System.out.println(APPLY_INTEREST + " - Creditar juro anual");
		System.out.println(EXIT + "- Sair");
	}
	private static void executeOption(Scanner in, SafeBankAccount account, String op) {
		switch (op) {
		case DEPOSIT: processDeposit(getIntValue(in), account); break;
		case WITHDRAW: processWithdraw(getIntValue(in), account); break;
		case GETBALANCE: in.nextLine(); processGetBalance(account); break;
		case COMPUTE_INTEREST: in.nextLine(); processComputeInterest(account); break;
		case APPLY_INTEREST: in.nextLine(); processApplyInterest(account); break;
		case SAVING_YEARS: processSavingYears(getIntValue(in), account); break;
		case EXIT: in.nextLine(); processExit(account); break;
		default: System.out.println("Valor inv�lido."); break;
		}
	}
	//pre: acc!= null && amount != null && amount>0 
	private static void processDeposit(int amount, SafeBankAccount acc) {
		if (amount>0) {
			acc.deposit(amount);
			System.out.println("Dep�sito efetuado com sucesso.");
		}
		else
			System.out.println("Dep�sito n�o efetuado. Valor inv�lido.");

	}
	//pre: acc!= null && amount != null && amount>0 && amount<=getBalance
	private static void processWithdraw(int amount, SafeBankAccount acc) {
		if(amount>0 && amount<=acc.getBalance()) {
			System.out.println("Levantamento efetuado com sucesso.");
			acc.withdraw(amount);
		}
		else if(amount>acc.getBalance()) {
			System.out.println("Levantamento n�o efetuado. Aplicada multa.");
			acc.withdraw(amount);
		}
		else if(amount<0)
			System.out.println("Levantamento n�o efetuado. Valor inv�lido.");
	}
	//pre: acc!= null
	private static void processGetBalance(SafeBankAccount acc) {	
		System.out.println("Tem na sua conta " +acc.getBalance()+ " centimos.");	
	}
	//pre: acc!= null
	private static void processComputeInterest(SafeBankAccount acc) {
		System.out.println(acc.computeInterest());
	}
	//pre: acc!= null
	private static void processApplyInterest(SafeBankAccount acc) {
		acc.applyInterest();
	}
	//pre: acc!= null
	private static void processExit(SafeBankAccount acc) {
		System.out.println("Ficou na sua conta " +acc.getBalance()+ " centimos.");	
	}
	//pre: target>getBalance && getBalance>100
	private static void processSavingYears(int target, SafeBankAccount acc) {
		System.out.println(acc.howManySavingYears(target));
	}
}
