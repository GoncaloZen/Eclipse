
public class SafeBankAccount {
	
	private int balance;
	public static final int FINE=200; 
	public static final int CATEGORY1 = 1000000;
	public static final int CATEGORY2 = 200000;
	public static final float RATE_CATEGORY1 = 0.01f;
	public static final float RATE_CATEGORY2 = 0.02f;
	public static final float RATE_CATEGORY3 = 0.03f;
	
	public SafeBankAccount() {balance=0;}  
	public SafeBankAccount (int amount) {balance = amount;}
	
	//Pre: amount>0
	public void deposit (int amount) {
		balance = balance + amount;
		} 
	public void withdraw (int amount) {
		if (amount<=balance)
			balance = balance - amount;
		else
			balance = balance - FINE;
	}
	
	public int getBalance() {return balance;}
	public boolean isInRedZone() {return(balance<0);} 
	
	public int computeInterest() {
		float interestRate ;
		if (balance > CATEGORY1)
			interestRate = RATE_CATEGORY3;
		else if (balance > CATEGORY2)
			interestRate = RATE_CATEGORY2;
		else 
			interestRate = RATE_CATEGORY1;
		return Math.round(balance * interestRate);	
	}
	
	public void applyInterest() {
		balance = balance + this.computeInterest();
	}
	public int howManySavingYears(int target) {
		SafeBankAccount auxAccount = new SafeBankAccount(getBalance());
		int years = 0;
		while(getBalance()<target) {
			years++;
			auxAccount.applyInterest();
		}
		return years;
	}
}
