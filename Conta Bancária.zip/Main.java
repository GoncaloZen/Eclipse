
public class Main {
	
	public static void main (String[] args) {
	BankAccount b1 = new BankAccount (10000);
	System.out.println("A conta tem saldo de " + b1.getBalance() +" c�ntimos.");
	b1.deposit(10);
	System.out.println("A conta tem saldo de " + b1.getBalance() +" c�ntimos.");
	b1.withdraw(200);
	System.out.println("A conta tem saldo de " + b1.getBalance() +" c�ntimos.");
	System.out.println("A conta est� com saldo negativo? " + b1.isInRedZone());
	
	}
}
