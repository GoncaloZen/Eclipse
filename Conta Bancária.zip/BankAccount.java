
public class BankAccount {
	
	private int balance; // Mem�ria. As suas variaveis s�o sempre privadas!! Se fosse publico podia se aceder diretamente � variavel no main, e assim podia se alterar o dinheiro da conta sem depositar ou retirar dinheiro, o que � mau para o banco!! (Declara��o)
	
	//Construtores (Defini��o do valor). Tem como sentido de vida inicializar as vari�veis de inst�ncia
	public BankAccount() {balance=0;}  //Construtor com zero parametros, n�o cria a conta com dinheiro
	public BankAccount (int amount) {balance = amount;}  //Construtor com um parametro, cria a conta com dinheiro. Esse dinheiro � o amount, que � definido na classe Main
	
	//Interface
	//Modificadores (Pre: amount>0)
	public void deposit (int amount) {balance = balance + amount;} //Adiciona dinheiro � conta 
	public void withdraw (int amount) {balance = balance - amount;} //Retira dinheiro � conta
	//Observadores
	public int getBalance() {return balance;} //Diz quanto dinheiro est� na conta
	public boolean isInRedZone() {return(balance<0);} //Diz se a conta tem saldo negativo ou positivo

}
