import java.util.Scanner;
public class Main {
	
	public static void main (String[] args) {
	Scanner input = new Scanner(System.in);
	//Criar conta
	SafeBankAccount account = createAccount(input, "cliente");
	printMenu();
	executeOption(input, account);
	input.close();
	}
	private static SafeBankAccount createAccount(Scanner in, String msg) {
		SafeBankAccount acc;
		//Pedir saldo inicial
		System.out.print("Saldo inicial da conta " + msg +": ");
		//Ler valor do utilizador
		int balance = getIntValue(in, "");
		//Validar valor do utilizador: Se for positivo criar a conta com o saldo indicado, se n�o criar a conta com saldo zero 
		if(balance>0)
			acc = new SafeBankAccount(balance);
		else
			acc = new SafeBankAccount();
		return acc;
		
	}
	private static int getIntValue(Scanner in, String msg) {
		System.out.print(msg);
		int val = in.nextInt(); in.nextLine();
		return val;
	}
	//Definir constantes para cada acao
	private static final int DEPOSIT = 1;
	private static final int WITHDRAW = 2;
	private static final int GETBALANCE = 3;
	private static final int COMPUTE_INTEREST = 4;
	private static final int APPLY_INTEREST = 5;
	private static final int EXIT = 6;
	
	private static void printMenu() {
		//Escrever o menu
		System.out.println(DEPOSIT + " - Depositar");
		System.out.println(WITHDRAW + " - Levantar");
		System.out.println(GETBALANCE + " - Consultar saldo");
		System.out.println(COMPUTE_INTEREST + " - Consultar juro anual");
		System.out.println(APPLY_INTEREST + " - Creditar juro anual");
		System.out.println(EXIT + "- Sair");
	}
	private static void  executeOption(Scanner in, SafeBankAccount acc) {
		//Pedir o numero da opcao e le-la
		int val = getIntValue(in, "Op��o: ");
		//De acordo com a opcao escolhida fazer a acao associada
		switch (val) {
		case DEPOSIT: processDeposit(in, acc); break;
		case WITHDRAW: processWithdraw(in, acc); break;
		case GETBALANCE: processGetBalance(acc); break;
		case COMPUTE_INTEREST: processComputeInterest(acc); break;
		case APPLY_INTEREST: processApplyInterest(acc); break;
		case EXIT: processExit(acc); break;
		default: System.out.println("Valor inv�lido."); break;
		}
	}
	private static void processDeposit(Scanner in, SafeBankAccount acc) {
		int amount = getIntValue(in, "Quanto deseja depositar? ");
		if (amount>0) {
			acc.deposit(amount);
			System.out.println("Dep�sito efetuado com sucesso.");
		}
		else
			System.out.println("Dep�sito n�o efetuado. Valor inv�lido.");

	}
	private static void processWithdraw(Scanner in, SafeBankAccount acc) {
		int amount = getIntValue(in, "Quanto deseja levantar? ");
		if(amount>0) {
			System.out.println("Levantamento efetuado com sucesso.");
			acc.withdraw(amount);
		}
		else
			System.out.println("Levantamento n�o efetuado. Valor inv�lido.");
	}
	private static void processGetBalance(SafeBankAccount acc) {	
		System.out.println(acc.getBalance());	
	}
	private static void processComputeInterest(SafeBankAccount acc) {
		System.out.println(acc.computeInterest());
	}
	private static void processApplyInterest(SafeBankAccount acc) {
		acc.applyInterest();
	}
	private static void processExit(SafeBankAccount acc) {
		System.out.println(acc.getBalance());
	}
}
