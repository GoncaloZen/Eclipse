import java.util.Scanner;
public class Main {
	
	public static void main (String[] args) {
		SafeBankAccount account;
		int balance;
		int amount;
	
		Scanner in = new Scanner(System.in);
		System.out.print("Saldo inicial: ");
		balance = in.nextInt(); //Porqu� assim??
		in.nextLine();
		if (balance>=0) { //Porqu� estes parenteses?
			account = new SafeBankAccount(balance); //Porque n�o "SafeBankAccount conta = new SafeBankAccount"?
			System.out.println("Quantia a levantar: ");
			amount = in.nextInt();
			in.nextLine();
			if (amount>0) {
				if(balance<amount)
					System.out.println("Levantamento n�o efetuado.");
				account.withdraw(amount);
				System.out.println("Saldo da conta= "+ account.getBalance() +" c�ntimos.");
			}
			else
				System.out.println("Levantamento inv�lido: n�o efetuado.");
		}
		else
			System.out.println("Saldo inicial negativo: Conta n�o criada.");
		in.close();	
	}
}
